print('sound mp3!')

def sound():
	print('mp3~~')