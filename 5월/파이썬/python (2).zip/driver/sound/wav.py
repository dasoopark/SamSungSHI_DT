print('sound wav!')

def sound():
	print('wav~~')