import hashlib
def get_pw(pw):
    pw = '1234'
    pw_to_bytes = bytes(pw,'utf8')
    m = hashlib.sha256()
    m.update( pw_to_bytes )
    return m.hexdigest()
    