def myfunc(a,b):
    return a-b