class myClass():
    def run(self):
        print('Run',__name__)
# 모듈 작성자가 현재 내용을 테스트 하기 위함
if __name__ == '__main__':
    m = MyClass()
    m.run()