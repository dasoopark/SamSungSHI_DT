from flask import Flask
from flask import render_template
import random

app = Flask(__name__) # 초기화

@app.route('/') # 요청 주소
def hello_world(): # 함수
    return 'Hello, World!' # 응답 결과

@app.route('/lotto') # 요청 주소
def lotto(): # 함수
    result = []
    for _ in range(3):
        temp = set()
        while True:
            n = random.randint(1,45)
            temp.add(n)
            if len(temp) == 6: break
        result.append(temp)
    return str(result) #응답 결과

if __name__ == '__main__':
    app.run(debug=True) # flask 실행